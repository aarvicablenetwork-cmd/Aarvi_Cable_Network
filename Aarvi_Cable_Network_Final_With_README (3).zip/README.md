
# Aarvi Cable Network

**Broadband | WiFi | FTTH | IPTV | OTT Services**  
📍 *Live in Telugu & English*

---

## 🌐 Website Overview | వెబ్‌సైట్ అవలోకనం
Welcome to the official website of **Aarvi Cable Network** – a leading local broadband service provider offering high-speed internet, OTT packs, and IPTV services.

**ఆర్వి కేబుల్ నెట్వర్క్** – మీ ఇంటికి హైస్పీడ్ బ్రాడ్‌బ్యాండ్, OTT, IPTV సేవలు అందించే విశ్వసనీయ ప్రొవైడర్.

---

## 📦 Plans Offered | ప్లాన్లు

- 40 Mbps
- 50 Mbps
- 75 Mbps
- 100 – 300 Mbps
- OTT + IPTV Combo Plans

---

## 📲 Contact | సంప్రదించండి

- 📞 Phone: 9032230411
- 💬 WhatsApp: [9951767700](https://wa.me/919951767700)
- 📧 Email: aarvinetwork@example.com *(optional)*

---

## 🧠 Technologies Used

- HTML5
- CSS3
- Responsive Layout
- Bilingual: English + Telugu

---

## 🖼️ Logo & Design

Includes red and blue themed logo with support for:
- FTTH, IPTV, WiFi icons
- Mobile friendly design
